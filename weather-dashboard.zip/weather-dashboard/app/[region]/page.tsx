import Link from "next/link";
import { citiesInRegion, REGIONS } from "@/lib/cities-config";
import { notFound } from "next/navigation";

export default function RegionPage({ params }: { params: { region: string } }) {
  if (!REGIONS.includes(params.region as never)) notFound();
  const cities = citiesInRegion(params.region);

  return (
    <div>
      <div className="text-subtext text-sm mb-2">
        <Link href="/">Regions</Link> / <span className="capitalize">{params.region}</span>
      </div>
      <h1 className="text-xl font-semibold mb-4 capitalize">{params.region} cities</h1>
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 max-w-3xl">
        {cities.map((c) => (
          <Link key={c.city} href={`/${params.region}/${encodeURIComponent(c.city)}`} className="card">
            <div className="capitalize">{c.city}</div>
            <div className="text-subtext text-xs">{c.timezone}</div>
          </Link>
        ))}
      </div>
    </div>
  );
}
