import { NextResponse } from "next/server";
import { CITIES, getLiveStatus } from "@/lib/cities-config";

export async function GET() {
  const now = new Date();
  const cities = CITIES.map((cfg) => {
    const status = getLiveStatus(cfg, now);
    return {
      city: cfg.city,
      region: cfg.region,
      cadenceMinutes: cfg.cadenceMinutes,
      ...status,
    };
  });

  return NextResponse.json({ generatedAt: now.toISOString(), cities });
}
