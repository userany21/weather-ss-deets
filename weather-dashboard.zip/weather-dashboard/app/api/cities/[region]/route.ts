import { NextResponse } from "next/server";
import { citiesInRegion } from "@/lib/cities-config";

export async function GET(_req: Request, { params }: { params: { region: string } }) {
  const cities = citiesInRegion(params.region);
  if (cities.length === 0) {
    return NextResponse.json({ error: "Unknown region" }, { status: 404 });
  }
  return NextResponse.json({ region: params.region, cities });
}
