import { NextResponse } from "next/server";
import { REGIONS, citiesInRegion } from "@/lib/cities-config";

export async function GET() {
  const regions = REGIONS.map((region) => ({
    region,
    cityCount: citiesInRegion(region).length,
  }));
  return NextResponse.json({ regions });
}
