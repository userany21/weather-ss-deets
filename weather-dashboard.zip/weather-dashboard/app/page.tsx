import Link from "next/link";
import { REGIONS, citiesInRegion } from "@/lib/cities-config";

export default function HomePage() {
  return (
    <div>
      <h1 className="text-xl font-semibold mb-4">Regions</h1>
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 max-w-2xl">
        {REGIONS.map((region) => (
          <Link key={region} href={`/${region}`} className="card">
            <div className="text-lg capitalize">{region}</div>
            <div className="text-subtext text-sm">{citiesInRegion(region).length} cities</div>
          </Link>
        ))}
      </div>
    </div>
  );
}
